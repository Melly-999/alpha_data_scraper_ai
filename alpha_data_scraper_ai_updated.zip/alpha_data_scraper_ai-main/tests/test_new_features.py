"""
Comprehensive test suite for new trading bot features.
Tests cover: indicators, signal generation, LSTM model, calculator, and integration.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from indicators import add_indicators
from signal_generator import (
    MarketRegime,
    SignalResult,
    detect_regime,
    generate_signal,
)
from lstm_model import LSTMPipeline, build_sequences
from calculator import atr_position_size, atr_stop_distance, position_size


# ============================================================================
# INDICATORS TESTS (15 tests)
# ============================================================================

def _create_sample_data(rows: int = 100) -> pd.DataFrame:
    """Create sample OHLCV data for testing."""
    np.random.seed(42)
    return pd.DataFrame({
        "open": 100 + np.random.randn(rows).cumsum(),
        "high": 101 + np.random.randn(rows).cumsum(),
        "low": 99 + np.random.randn(rows).cumsum(),
        "close": 100 + np.random.randn(rows).cumsum(),
        "volume": np.random.randint(1000, 10000, rows),
    })


def test_indicators_atr_exists():
    """Test that ATR column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "atr" in result.columns


def test_indicators_atr_pct_exists():
    """Test that ATR% column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "atr_pct" in result.columns


def test_indicators_atr_positive():
    """Test that ATR values are positive."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert (result["atr"] >= 0).all()


def test_indicators_atr_pct_positive():
    """Test that ATR% values are positive."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert (result["atr_pct"] >= 0).all()


def test_indicators_adx_exists():
    """Test that ADX column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "adx" in result.columns


def test_indicators_plus_di_exists():
    """Test that +DI column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "plus_di" in result.columns


def test_indicators_minus_di_exists():
    """Test that -DI column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "minus_di" in result.columns


def test_indicators_adx_range():
    """Test that ADX values are in valid range (0-100)."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert (result["adx"] >= 0).all()
    assert (result["adx"] <= 100).all()


def test_indicators_obv_zscore_exists():
    """Test that OBV z-score column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "obv_zscore" in result.columns


def test_indicators_vwap_dev_exists():
    """Test that VWAP deviation column is added."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert "vwap_dev" in result.columns


def test_indicators_all_new_columns_present():
    """Test that all new indicator columns are present."""
    df = _create_sample_data()
    result = add_indicators(df)
    new_cols = ["atr", "atr_pct", "adx", "plus_di", "minus_di", "obv_zscore", "vwap_dev"]
    for col in new_cols:
        assert col in result.columns


def test_indicators_no_inf_values():
    """Test that there are no infinite values in indicators."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert not np.isinf(result.values).any()


def test_indicators_no_nan_values():
    """Test that there are no NaN values in indicators."""
    df = _create_sample_data()
    result = add_indicators(df)
    assert not result.isna().any().any()


def test_indicators_backward_compatibility():
    """Test that original indicators still exist."""
    df = _create_sample_data()
    result = add_indicators(df)
    original_cols = ["rsi", "stoch_k", "stoch_d", "macd", "macd_signal", "macd_hist", "bb_pos"]
    for col in original_cols:
        assert col in result.columns


def test_indicators_output_length():
    """Test that output has fewer rows due to dropna."""
    df = _create_sample_data(100)
    result = add_indicators(df)
    assert len(result) < len(df)
    assert len(result) > 0


# ============================================================================
# SIGNAL GENERATOR TESTS (15 tests)
# ============================================================================

def _create_sample_series() -> pd.Series:
    """Create sample indicator series for testing."""
    return pd.Series({
        "rsi": 50.0,
        "stoch_k": 50.0,
        "stoch_d": 50.0,
        "macd_hist": 0.0,
        "bb_pos": 0.5,
        "atr": 1.5,
        "atr_pct": 1.5,
        "adx": 20.0,
        "plus_di": 20.0,
        "minus_di": 20.0,
        "obv_zscore": 0.0,
        "vwap_dev": 0.0,
    })


def test_market_regime_enum():
    """Test that MarketRegime enum exists and has correct values."""
    assert hasattr(MarketRegime, "TRENDING")
    assert hasattr(MarketRegime, "RANGING")
    assert hasattr(MarketRegime, "VOLATILE")


def test_detect_regime_trending():
    """Test regime detection for trending market."""
    series = _create_sample_series()
    series["adx"] = 30.0
    series["atr_pct"] = 2.0
    regime = detect_regime(series)
    assert regime == MarketRegime.TRENDING


def test_detect_regime_volatile():
    """Test regime detection for volatile market."""
    series = _create_sample_series()
    series["adx"] = 15.0
    series["atr_pct"] = 4.0
    regime = detect_regime(series)
    assert regime == MarketRegime.VOLATILE


def test_detect_regime_ranging():
    """Test regime detection for ranging market."""
    series = _create_sample_series()
    series["adx"] = 15.0
    series["atr_pct"] = 2.0
    regime = detect_regime(series)
    assert regime == MarketRegime.RANGING


def test_generate_signal_returns_signalresult():
    """Test that generate_signal returns SignalResult object."""
    series = _create_sample_series()
    result = generate_signal(series, lstm_delta=0.5)
    assert isinstance(result, SignalResult)


def test_generate_signal_buy_signal():
    """Test that strong bullish indicators produce BUY signal."""
    series = _create_sample_series()
    series["rsi"] = 30.0
    series["macd_hist"] = 0.5
    series["bb_pos"] = 0.1
    series["adx"] = 30.0
    series["plus_di"] = 40.0
    series["minus_di"] = 20.0
    result = generate_signal(series, lstm_delta=0.5)
    assert result.signal == "BUY"


def test_generate_signal_sell_signal():
    """Test that strong bearish indicators produce SELL signal."""
    series = _create_sample_series()
    series["rsi"] = 70.0
    series["macd_hist"] = -0.5
    series["bb_pos"] = 0.9
    series["adx"] = 30.0
    series["plus_di"] = 20.0
    series["minus_di"] = 40.0
    result = generate_signal(series, lstm_delta=-0.5)
    assert result.signal == "SELL"


def test_generate_signal_hold_signal():
    """Test that neutral indicators produce HOLD signal."""
    series = _create_sample_series()
    result = generate_signal(series, lstm_delta=0.0)
    assert result.signal == "HOLD"


def test_generate_signal_with_uncertainty():
    """Test that high uncertainty reduces LSTM weight."""
    series = _create_sample_series()
    # Without uncertainty
    result1 = generate_signal(series, lstm_delta=0.5, lstm_uncertainty=0.0)
    # With high uncertainty
    result2 = generate_signal(series, lstm_delta=0.5, lstm_uncertainty=3.0)
    assert result1.score >= result2.score  # Uncertainty should reduce score


def test_generate_signal_adaptive_confidence():
    """Test that volatile regime reduces confidence."""
    series = _create_sample_series()
    series["atr_pct"] = 5.0  # High volatility
    result = generate_signal(series, lstm_delta=0.5)
    assert "confidence adjusted" in " ".join(result.reasons)


def test_generate_signal_adx_scoring():
    """Test that ADX contributes to score."""
    series = _create_sample_series()
    series["adx"] = 30.0
    series["plus_di"] = 40.0
    series["minus_di"] = 20.0
    result = generate_signal(series, lstm_delta=0.0)
    assert any("ADX" in r for r in result.reasons)


def test_generate_signal_obv_scoring():
    """Test that OBV z-score contributes to score."""
    series = _create_sample_series()
    series["obv_zscore"] = 2.0
    result = generate_signal(series, lstm_delta=0.0)
    assert any("OBV" in r for r in result.reasons)


def test_generate_signal_vwap_scoring():
    """Test that VWAP deviation contributes to score."""
    series = _create_sample_series()
    series["vwap_dev"] = -3.0
    result = generate_signal(series, lstm_delta=0.0)
    assert any("VWAP" in r for r in result.reasons)


def test_generate_signal_confidence_range():
    """Test that confidence is always in valid range."""
    series = _create_sample_series()
    for lstm_delta in [-2.0, -1.0, 0.0, 1.0, 2.0]:
        result = generate_signal(series, lstm_delta=lstm_delta)
        assert 0 <= result.confidence <= 100


def test_generate_signal_backward_compatible():
    """Test that generate_signal works without new indicators (backward compatible)."""
    series = pd.Series({
        "rsi": 50.0,
        "stoch_k": 50.0,
        "stoch_d": 50.0,
        "macd_hist": 0.0,
        "bb_pos": 0.5,
    })
    result = generate_signal(series, lstm_delta=0.0)
    assert isinstance(result, SignalResult)


# ============================================================================
# LSTM MODEL TESTS (10 tests)
# ============================================================================

def test_lstm_pipeline_ensemble_size():
    """Test that ensemble_size parameter exists and defaults to 1."""
    pipeline = LSTMPipeline()
    assert pipeline.ensemble_size == 1


def test_lstm_pipeline_multiple_models():
    """Test that ensemble creates multiple models."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]]
    
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=3)
    pipeline.fit(features)
    assert len(pipeline._models) == 3


def test_lstm_pipeline_model_property():
    """Test backward compatibility: model property returns first model."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]]
    
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=2)
    pipeline.fit(features)
    assert pipeline.model == pipeline._models[0]


def test_lstm_pipeline_prediction_uncertainty():
    """Test that prediction_uncertainty method exists."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]]
    
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=3)
    pipeline.fit(features)
    uncertainty = pipeline.prediction_uncertainty(features)
    assert isinstance(uncertainty, float)
    assert uncertainty >= 0


def test_lstm_pipeline_single_model_no_uncertainty():
    """Test that single model returns 0 uncertainty."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]]
    
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=1)
    pipeline.fit(features)
    uncertainty = pipeline.prediction_uncertainty(features)
    assert uncertainty == 0.0


def test_lstm_pipeline_ensemble_reduces_variance():
    """Test that ensemble predictions have lower variance than single model."""
    # This is a statistical property, so we just check the method runs
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]]
    
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=3)
    pipeline.fit(features)
    delta = pipeline.predict_next_delta(features)
    assert isinstance(delta, float)


def test_lstm_build_sequences():
    """Test sequence building utility function."""
    values = np.random.randn(100, 3)
    x, y = build_sequences(values, lookback=10)
    assert x.shape == (90, 10, 3)
    assert y.shape == (90,)


def test_lstm_pipeline_fit_small_data():
    """Test that pipeline falls back to NaiveSequenceModel for small data."""
    df = _create_sample_data(5)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]] if len(data) > 0 else pd.DataFrame()
    
    if len(features) < 10:
        pipeline = LSTMPipeline(lookback=10, epochs=1)
        pipeline.fit(features)
        assert len(pipeline._models) == 1


def test_lstm_pipeline_predict_short_data():
    """Test that predict returns 0 for insufficient data."""
    df = _create_sample_data(5)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]] if len(data) > 0 else pd.DataFrame()
    
    if len(features) < 10:
        pipeline = LSTMPipeline(lookback=50, epochs=1)
        pipeline.fit(features)
        delta = pipeline.predict_next_delta(features)
        assert delta == 0.0


def test_lstm_pipeline_backward_compatible():
    """Test that LSTMPipeline works without ensemble_size parameter."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist"]]
    
    # Don't specify ensemble_size (should default to 1)
    pipeline = LSTMPipeline(lookback=10, epochs=1)
    pipeline.fit(features)
    delta = pipeline.predict_next_delta(features)
    assert isinstance(delta, float)


# ============================================================================
# CALCULATOR TESTS (5 tests)
# ============================================================================

def test_atr_stop_distance():
    """Test ATR stop distance calculation."""
    atr = 2.0
    distance = atr_stop_distance(atr, multiplier=2.0)
    assert distance == 4.0


def test_atr_position_size():
    """Test ATR-based position sizing."""
    lot = atr_position_size(
        balance=10000.0,
        risk_pct=0.01,
        atr=2.0,
        atr_multiplier=2.0,
        point_value=1.0
    )
    assert lot >= 0.01
    assert isinstance(lot, float)


def test_atr_position_size_zero_atr():
    """Test that zero ATR returns minimum lot size."""
    lot = atr_position_size(
        balance=10000.0,
        risk_pct=0.01,
        atr=0.0,
        point_value=1.0
    )
    assert lot == 0.01


def test_position_size_backward_compatible():
    """Test that original position_size function still works."""
    lot = position_size(
        balance=10000.0,
        risk_pct=0.01,
        sl_points=100,
        point_value=1.0
    )
    assert lot >= 0.01
    assert isinstance(lot, float)


def test_calculator_functions_return_floats():
    """Test that all calculator functions return floats."""
    atr_lot = atr_position_size(10000.0, 0.01, 2.0, 2.0, 1.0)
    fixed_lot = position_size(10000.0, 0.01, 100, 1.0)
    stop_dist = atr_stop_distance(2.0, 2.0)
    
    assert isinstance(atr_lot, float)
    assert isinstance(fixed_lot, float)
    assert isinstance(stop_dist, float)


# ============================================================================
# INTEGRATION TESTS (5 tests)
# ============================================================================

def test_full_pipeline_with_new_features():
    """Test complete pipeline: indicators -> LSTM -> signal with all new features."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    
    # Check all new columns exist
    assert all(col in data.columns for col in ["atr", "adx", "obv_zscore", "vwap_dev"])
    
    # Train LSTM with ensemble
    features = data[["close", "rsi", "macd_hist", "atr", "adx"]]
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=2)
    pipeline.fit(features)
    
    # Get prediction and uncertainty
    lstm_delta = pipeline.predict_next_delta(features)
    lstm_uncertainty = pipeline.prediction_uncertainty(features)
    
    # Generate signal with regime detection
    latest = data.iloc[-1]
    signal = generate_signal(latest, lstm_delta=lstm_delta, lstm_uncertainty=lstm_uncertainty)
    regime = detect_regime(latest)
    
    assert isinstance(signal, SignalResult)
    assert isinstance(regime, MarketRegime)
    assert signal.signal in ["BUY", "SELL", "HOLD"]


def test_integration_with_atr_sizing():
    """Test integration of ATR indicators with position sizing."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    
    latest_atr = float(data.iloc[-1]["atr"])
    lot = atr_position_size(10000.0, 0.01, latest_atr, 2.0, 1.0)
    
    assert lot >= 0.01
    assert isinstance(lot, float)


def test_regime_affects_confidence():
    """Test that different regimes produce different confidence levels."""
    # Create two identical series but different regimes
    series1 = _create_sample_series()
    series1["adx"] = 30.0  # Trending
    series1["atr_pct"] = 2.0
    
    series2 = _create_sample_series()
    series2["adx"] = 15.0  # Volatile
    series2["atr_pct"] = 5.0
    
    signal1 = generate_signal(series1, lstm_delta=0.5)
    signal2 = generate_signal(series2, lstm_delta=0.5)
    
    # Volatile regime should have lower confidence
    assert signal2.confidence < signal1.confidence


def test_ensemble_uncertainty_integration():
    """Test that ensemble uncertainty properly integrates with signal generation."""
    df = _create_sample_data(200)
    data = add_indicators(df)
    features = data[["close", "rsi", "macd_hist", "atr"]]
    
    pipeline = LSTMPipeline(lookback=10, epochs=1, ensemble_size=3)
    pipeline.fit(features)
    
    lstm_delta = pipeline.predict_next_delta(features)
    lstm_uncertainty = pipeline.prediction_uncertainty(features)
    
    # High uncertainty signal should have lower score
    latest = data.iloc[-1]
    signal_low_unc = generate_signal(latest, lstm_delta=lstm_delta, lstm_uncertainty=0.0)
    signal_high_unc = generate_signal(latest, lstm_delta=lstm_delta, lstm_uncertainty=3.0)
    
    # Signal with uncertainty should mention it in reasons
    assert any("unc=" in r for r in signal_high_unc.reasons)


def test_backward_compatibility_full_pipeline():
    """Test that old code still works without new features."""
    df = _create_sample_data(200)
    # Only use original indicators
    data = pd.DataFrame({
        "close": df["close"],
        "rsi": 50.0,
        "stoch_k": 50.0,
        "stoch_d": 50.0,
        "macd_hist": 0.0,
        "bb_pos": 0.5,
        "volume": 1000,
    })
    
    # Old-style signal generation (without uncertainty)
    latest = data.iloc[-1]
    signal = generate_signal(latest, lstm_delta=0.0)
    
    assert isinstance(signal, SignalResult)
    assert signal.signal in ["BUY", "SELL", "HOLD"]
