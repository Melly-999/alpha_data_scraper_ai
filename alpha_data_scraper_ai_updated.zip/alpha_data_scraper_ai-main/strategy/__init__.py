"""Trading strategies and signals."""
